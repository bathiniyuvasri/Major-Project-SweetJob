export class Jobs {
    designation:any
    company_name:any
    location:any
  
    constructor(designation: any, company_name: any, location: any){
        this.designation=designation;
        this.company_name=company_name;
        this.location=location;
  
    }
  }
  