import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { EmployerComponent } from './components/employer/employer.component';
import { JobseekersComponent } from './components/jobseekers/jobseekers.component';
import { EmployerAddjobComponent } from './components/employer-addjob/employer-addjob.component';
import { JobseekersAppComponent } from './components/jobseekers-app/jobseekers-app.component';
import { HomePageComponent } from './components/home-page/home-page.component';
import { JobseekersLoginComponent } from './components/jobseekers-login/jobseekers-login.component';
import { EmployerLoginComponent } from './components/employer-login/employer-login.component';
import { EmployeeRegisterComponent } from './components/employee-register/employee-register.component';
import { JobseekerRegisterComponent } from './components/jobseeker-register/jobseeker-register.component';
import { EmployeeListComponent } from './components/employee-list/employee-list.component';
import { JobseekerListComponent } from './components/jobseeker-list/jobseeker-list.component';
import { SearchJobsComponent } from './components/search-jobs/search-jobs.component';
import { AdminComponent } from './components/admin/admin.component';
import { AdminLoginComponent } from './components/admin-login/admin-login.component';
import { JobseekerUpdateComponent } from './components/jobseeker-update/jobseeker-update.component';
import { AddedEmployeeJoblistComponent } from './components/added-employee-joblist/added-employee-joblist.component';
const routes: Routes = [
{path:'seekerlogin', component:JobseekersLoginComponent},
{path:'jobposted', component:AddedEmployeeJoblistComponent},
{path:'addjob', component:EmployerAddjobComponent},
{path:'emp', component:EmployerComponent},
{path:'jobseekerupdate/:id', component:JobseekerUpdateComponent, pathMatch:'full'},
{path:'jobseeker', component:JobseekersComponent},
{path:'emplist', component:EmployeeListComponent},
{path:'jobseekerlist', component:JobseekerListComponent},
{path:'jobapp', component:JobseekersAppComponent},
{path:'search', component:SearchJobsComponent},
{path:'admin', component:AdminComponent},
{path:'adminlogin', component:AdminLoginComponent},
{path:'empregister', component:EmployeeRegisterComponent},
{path:'seekerregister', component:JobseekerRegisterComponent},
{path:'emplogin', component:EmployerLoginComponent},
{path:'', component:HomePageComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
