import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { HttpClientModule } from '@angular/common/http';
import { FormsModule } from '@angular/forms';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { HomePageComponent } from './components/home-page/home-page.component';
import { FooterComponent } from './components/footer/footer.component';
import { SiteLayoutComponent } from './components/site-layout/site-layout.component';
import { EmployerComponent } from './components/employer/employer.component';
import { JobseekersComponent } from './components/jobseekers/jobseekers.component';
import { EmployerAddjobComponent } from './components/employer-addjob/employer-addjob.component';
import { JobseekersAppComponent } from './components/jobseekers-app/jobseekers-app.component';
import { JobseekersLoginComponent } from './components/jobseekers-login/jobseekers-login.component';
import { EmployerLoginComponent } from './components/employer-login/employer-login.component';
import { HeaderComponent } from './components/header/header.component';
import { EmployeeRegisterComponent } from './components/employee-register/employee-register.component';
import { JobseekerRegisterComponent } from './components/jobseeker-register/jobseeker-register.component';
import { AddedEmployeeJoblistComponent } from './components/added-employee-joblist/added-employee-joblist.component';
import { SearchfilterPipe } from './searchfilter.pipe';
import { SearchJobsComponent } from './components/search-jobs/search-jobs.component';
import { AdminComponent } from './components/admin/admin.component';
import { AdminLoginComponent } from './components/admin-login/admin-login.component';
import { EmployeeListComponent } from './components/employee-list/employee-list.component';
import { JobseekerListComponent } from './components/jobseeker-list/jobseeker-list.component';
import { JobseekerUpdateComponent } from './components/jobseeker-update/jobseeker-update.component';


@NgModule({
  declarations: [
    AppComponent,
    HomePageComponent,
    FooterComponent,
    SiteLayoutComponent,
    EmployerComponent,
    JobseekersComponent,
    EmployerAddjobComponent,
    JobseekersAppComponent,
    JobseekersLoginComponent,
    EmployerLoginComponent,
    HeaderComponent,
    EmployeeRegisterComponent,
    JobseekerRegisterComponent,
    AddedEmployeeJoblistComponent,
    SearchfilterPipe,
    SearchJobsComponent,
    AdminComponent,
    AdminLoginComponent,
    EmployeeListComponent,
    JobseekerListComponent,
    JobseekerUpdateComponent,
    
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    HttpClientModule
  ],
  providers: [],
  bootstrap: [SiteLayoutComponent]
})
export class AppModule { }
