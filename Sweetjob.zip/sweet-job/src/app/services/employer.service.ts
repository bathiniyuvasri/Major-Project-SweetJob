import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Jobs } from "./../jobs";
@Injectable({
  providedIn: 'root'
})
export class EmployerService {
  apiUrl:string = "http://localhost:5555/employers/"
  baseUrl:string = "http://localhost:5555/jobs/"
  api_url:string = "http://localhost:3000/v1/user/"
  constructor(private http: HttpClient) { }
  createEmployer(body: string) {
    let headers = new HttpHeaders({'Content-Type': 'application/x-www-form-urlencoded'});
    return this.http.post(this.api_url, body, {headers: headers, responseType:'text'});
  }
  getEmpById(emailid:any,password:any) {
    return this.http.get<any>(this.api_url + "emailid" + "password");
  }
  addJob(body: string) {
    let headers = new HttpHeaders({'Content-Type': 'application/x-www-form-urlencoded'});
    return this.http.post(this.baseUrl, body, {headers: headers, responseType:'text'});
  }
  getjobs() {
    return this.http.get<Jobs[]>(this.baseUrl);
  }
  getEmployees() {
    return this.http.get(this.api_url);
  }
  deleteEmployee(empid:any) {
    return this.http.delete(this.api_url + empid);
  }

  getEmployeeById(empid:any) {
    return this.http.get<any>(this.api_url + empid);
  }

  updateEmployee(body: string, empid: string) {
    let headers = new HttpHeaders({'Content-Type': 'application/x-www-form-urlencoded'});
    return this.http.put(this.api_url + empid, body, {headers: headers, responseType:'text'});
  }
  getJobs() {
    return this.http.get(this.baseUrl);
  }
  deleteJob(jobid:any) {
    return this.http.delete(this.baseUrl + jobid);
  }

  getJobById(jobid:any) {
    return this.http.get<any>(this.baseUrl + jobid);
  }

  updateJob(body: string, jobid: string) {
    let headers = new HttpHeaders({'Content-Type': 'application/x-www-form-urlencoded'});
    return this.http.put(this.baseUrl + jobid, body, {headers: headers, responseType:'text'});
  }
  checkValidUser(body: string) {
    let headers = new HttpHeaders({'Content-Type': 'application/x-www-form-urlencoded'});
    return this.http.post(this.api_url + 'login', body, {headers: headers, responseType:'text'});
  }
}
