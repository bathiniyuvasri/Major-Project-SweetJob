import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
@Injectable({
  providedIn: 'root'
})
export class JobseekersService {
  apiUrl:string = "http://localhost:5555/jobseekers/"
  // baseUrl:string= "http://localhost:3000/v1/user//delete/:id"
  api_url:string = "http://localhost:3000/v1/user/"
  constructor(private http: HttpClient) { }
  createjobseekers(body: string) {
    let headers = new HttpHeaders({'Content-Type': 'application/x-www-form-urlencoded'});
    return this.http.post(this.api_url, body, {headers: headers, responseType:'text'});
  }
  createUser(body: string) {
    let headers = new HttpHeaders({'Content-Type': 'application/x-www-form-urlencoded'});
    return this.http.post(this.api_url, body, {headers: headers, responseType:'text'});
  }

  getJobseekers() {
    return this.http.get(this.api_url);
  }
  deleteJobseekers(jobseekerid:any) {
    return this.http.delete(this.api_url + jobseekerid);
  }

  getJobseekersById(jobseekerid:any) {
    return this.http.get<any>(this.api_url + jobseekerid);
  }

  updateJobseekers(body: string, jobseekerid: string) {
    let headers = new HttpHeaders({'Content-Type': 'application/x-www-form-urlencoded'});
    return this.http.put(this.api_url + jobseekerid, body, {headers: headers, responseType:'text'});
  }
  checkValidUser(body: string) {
    let headers = new HttpHeaders({'Content-Type': 'application/x-www-form-urlencoded'});
    return this.http.post(this.api_url + 'login', body, {headers: headers, responseType:'text'});
  }
}