import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-jobseekers',
  templateUrl: './jobseekers.component.html',
  styleUrls: ['./jobseekers.component.css']
})
export class JobseekersComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
