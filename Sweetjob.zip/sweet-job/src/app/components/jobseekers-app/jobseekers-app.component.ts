import { Component, OnInit } from '@angular/core';
import { Router } from "@angular/router";
import { JobseekersService } from "./../../services/jobseekers.service";
@Component({
  selector: 'app-jobseekers-app',
  templateUrl: './jobseekers-app.component.html',
  styleUrls: ['./jobseekers-app.component.css']
})
export class JobseekersAppComponent implements OnInit {
  qualification:any
  experience:any
  location:any
  cv:any
  message = ''

  constructor(private router:Router, private jobseekersService:JobseekersService) { }

  ngOnInit(): void {
  }

  applyjob = () => {
    var body = "&qualification=" + this.qualification
        + "&location=" + this.location 
        + "&experience=" + this.experience
        + "&cv=" + this.cv;
    this.jobseekersService.createjobseekers(body)
      .subscribe( data => {
        this.router.navigate(['userlist']);
      },
      (error) => {
        this.message = error.error
      });
  }

  clearMessage() {
    this.message = ''
  }

}
