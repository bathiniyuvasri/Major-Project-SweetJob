import { Component, OnInit } from '@angular/core';
import { Router } from "@angular/router";
import { EmployerService } from "./../../services/employer.service";
@Component({
  selector: 'app-employee-register',
  templateUrl: './employee-register.component.html',
  styleUrls: ['./employee-register.component.css']
})
export class EmployeeRegisterComponent implements OnInit {
  username:any
  address:any
  phoneno1:any
  phoneno2:any
  emailid:any
  password:any
  password_2:any
  blacklist:any
  
  message = ''
  constructor(private router:Router, private empService:EmployerService) { }

  ngOnInit(): void {
  }
  empRegister = () => {
    var body = "username=" + this.username
        + "&address=" + this.address 
        + "&phoneno1=" + this.phoneno1
        + "&phoneno2=" + this.phoneno2
        + "&emailid=" + this.emailid
        + "&password=" + this.password
        + "&password_2=" + this.password_2
        + "&blacklist=" + false
        + "&comments=" + '';
    this.empService.createEmployer(body)
      .subscribe( data => {
        this.router.navigate(['emplogin']);
        alert("register successfully")
      },
      (error) => {
        this.message = error.error
      });
  }

  clearMessage() {
    this.message = ''
  }
  
}
