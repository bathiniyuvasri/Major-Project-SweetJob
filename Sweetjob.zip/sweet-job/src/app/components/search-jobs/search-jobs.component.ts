import { Component, OnInit } from '@angular/core';
import { EmployerService } from "./../../services/employer.service";
import { Jobs } from "./../../jobs"
@Component({
  selector: 'app-search-jobs',
  templateUrl: './search-jobs.component.html',
  styleUrls: ['./search-jobs.component.css']
})
export class SearchJobsComponent implements OnInit {

  Jobs: Jobs[]=[]
  searchValue: any


  constructor(private empService: EmployerService) { } //npm i ng2-search-filter

  ngOnInit(): void {
    this.empService.getjobs().subscribe((response) => {
      this.Jobs = <any>response;
    });
  }
}
