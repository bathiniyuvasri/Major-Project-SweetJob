import { ComponentFixture, TestBed } from '@angular/core/testing';

import { EmployerAddjobComponent } from './employer-addjob.component';

describe('EmployerAddjobComponent', () => {
  let component: EmployerAddjobComponent;
  let fixture: ComponentFixture<EmployerAddjobComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ EmployerAddjobComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(EmployerAddjobComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
