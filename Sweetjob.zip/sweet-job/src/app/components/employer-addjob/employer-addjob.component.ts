import { Component, OnInit } from '@angular/core';
import { Router } from "@angular/router";
import { EmployerService } from "./../../services/employer.service";
@Component({
  selector: 'app-employer-addjob',
  templateUrl: './employer-addjob.component.html',
  styleUrls: ['./employer-addjob.component.css']
})
export class EmployerAddjobComponent implements OnInit {
  designation:any
  username:any
  location:any

  
  
  
  message = ''
  constructor(private router:Router, private empService:EmployerService) { }

  ngOnInit(): void {
  }
  addjob = () => {
    var body = "&username=" + this.username
        + "&location=" + this.location 
        + "&designation=" + this.designation;
    this.empService.addJob(body)
      .subscribe( data => {
        this.router.navigate(['emp']);
        alert("payed successfully")
      },
      (error) => {
        this.message = error.error
      });
  }

  clearMessage() {
    this.message = ''
  }
  
}
